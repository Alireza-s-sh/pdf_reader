package com.example.book_reader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
