import 'dart:io';
import 'package:book_reader/admin_panel.dart';
import 'package:book_reader/models/file_data.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:hive/hive.dart';
import 'package:open_file/open_file.dart';
import '../utils/check_permission.dart';
import '../utils/directory_path.dart';
import '../static_files.dart';

class AdminFileList extends StatefulWidget {
  const AdminFileList({Key? key}) : super(key: key);

  @override
  State<AdminFileList> createState() => _FileListState();
}

class _FileListState extends State<AdminFileList> {
  bool isPermission = false;
  var checkAllPermissions = CheckPermission();
  final _fileDataBox = Hive.box<FileData>('files');
  final dataList = List.from(dataListStatic);
  late List<FileData> combinedData =
      []; // Initialize combinedData with an empty list
  late CancelToken cancelToken;
  checkPermission() async {
    var permission = await checkAllPermissions.isStoragePermission();
    if (permission) {
      setState(() {
        isPermission = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    checkPermission(); // Correct call to checkPermission
    loadFiles(); // Load files during initialization
  }

  Future<void> loadFiles() async {
    // Load data from Hive and static list
    combinedData = [
      ...dataList.map((item) => FileData(
            fileName: item['fileName'] ?? '',
            fileUrl: item['fileUrl'] ?? '',
            fileDescription: item['fileDescription'] ?? '',
          )),
      ..._fileDataBox.values.toList()
    ];
    setState(() {}); // Update the state to reflect the loaded data
  }

  Future<void> refreshFiles() async {
    await loadFiles();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: HexColor("#f5f5f5"),
      appBar: AppBar(
        backgroundColor: HexColor("#f5f5f5"),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 16.0),
              child: Text(
                'Books',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: HexColor("#4F4F4F"),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 0.0),
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return AdminPanel();
                      },
                    ),
                  );
                },
                child: Text(
                  'Admin Panel',
                  style: TextStyle(
                    color: HexColor("#00a676"),
                    fontSize: 19,
                  ),
                ),
              ),
            ),
          ],
        ),
        centerTitle: true,
      ),
      body: isPermission
          ? RefreshIndicator(
              onRefresh: refreshFiles,
              child: Stack(
                children: [
                  ListView.builder(
                    padding: const EdgeInsets.all(8.0),
                    itemCount: combinedData.length,
                    itemBuilder: (BuildContext context, int index) {
                      var data = combinedData[index];
                      return TileList(
                        fileName: data.fileName,
                        fileUrl: data.fileUrl,
                        fileDescription: data.fileDescription,
                      );
                    },
                  ),
                ],
              ),
            )
          : Center(
              child: ElevatedButton(
                onPressed: () {
                  checkPermission(); // Correct call to checkPermission
                },
                child: const Text("Grant Storage Permission"),
              ),
            ),
    );
  }
}

class TileList extends StatefulWidget {
  const TileList({
    Key? key,
    required this.fileName,
    required this.fileUrl,
    required this.fileDescription,
  }) : super(key: key);

  final String fileName;
  final String fileUrl;
  final String fileDescription;

  @override
  State<TileList> createState() => _TileListState();
}

class _TileListState extends State<TileList> {
  bool downloading = false;
  bool fileExists = false;
  double progress = 0;
  late String filePath;
  late CancelToken cancelToken;
  var getPathFile = DirectoryPath();

  startDownload() async {
    cancelToken = CancelToken();
    var storePath = await getPathFile.getPath();
    filePath = '$storePath/${widget.fileName}';

    setState(() {
      downloading = true;
      progress = 0;
    });

    try {
      await Dio().download(
        widget.fileUrl,
        filePath,
        onReceiveProgress: (count, total) {
          setState(() {
            progress = count / total;
          });
        },
        cancelToken: cancelToken,
      );

      setState(() {
        downloading = false;
        fileExists = true;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Download complete: ${widget.fileName}'),
          duration: const Duration(seconds: 3),
        ),
      );
    } catch (e) {
      print('Error downloading file: $e');
      setState(() {
        downloading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to download file: ${widget.fileName}'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  cancelDownload() {
    cancelToken.cancel();
    setState(() {
      downloading = false;
    });
  }

  checkFileExist() async {
    var storePath = await getPathFile.getPath();
    filePath = '$storePath/${widget.fileName}';
    bool fileExistCheck = await File(filePath).exists();
    setState(() {
      fileExists = fileExistCheck;
    });
  }

  deleteFile() async {
    var storePath = await getPathFile.getPath();
    filePath = '$storePath/${widget.fileName}';
    try {
      if (await File(filePath).exists()) {
        await File(filePath).delete();
        setState(() {
          fileExists = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('File deleted: ${widget.fileName}'),
            duration: const Duration(seconds: 3),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('File does not exist: ${widget.fileName}'),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      print('Error deleting file: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to delete file: ${widget.fileName}'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  openFile() {
    OpenFile.open(filePath);
  }

  @override
  void initState() {
    super.initState();
    checkFileExist();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20.0),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 10.0,
              spreadRadius: 5.0,
            ),
          ],
        ),
        child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: HexColor("#e0f7fa"),
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: const Icon(
                  Icons.picture_as_pdf,
                  size: 24.0,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.fileName,
                    style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w600,
                        color: HexColor("#4F4F4F")),
                  ),
                  const SizedBox(height: 4),
                ],
              ),
            ],
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!downloading && !fileExists)
                GestureDetector(
                  onTap: startDownload,
                  child: Icon(
                    Icons.file_download_outlined,
                    color: HexColor("#00796B"),
                    size: 28.0,
                  ),
                ),
              if (downloading)
                SizedBox(
                  width: 28.0,
                  height: 28.0,
                  child: Stack(
                    children: [
                      CircularProgressIndicator(
                        value: progress,
                        strokeWidth: 3,
                        backgroundColor: Colors.grey[200],
                        valueColor: AlwaysStoppedAnimation<Color>(
                          HexColor("#44564a"),
                        ),
                      ),
                      Center(
                        child: Text(
                          '${(progress * 100).toStringAsFixed(0)}%',
                          style: TextStyle(fontSize: 11, color: Colors.black),
                        ),
                      ),
                    ],
                  ),
                ),
              if (fileExists)
                GestureDetector(
                  onTap: openFile,
                  child: Icon(
                    Icons.insert_drive_file,
                    color: HexColor("#00a676"),
                    size: 28.0,
                  ),
                ),
              if (downloading)
                GestureDetector(
                  onTap: cancelDownload,
                  child: const Icon(
                    Icons.cancel,
                    color: Colors.red,
                    size: 28.0,
                  ),
                ),
              if (fileExists)
                GestureDetector(
                  onTap: deleteFile,
                  child: const Icon(
                    Icons.delete,
                    color: Colors.red,
                    size: 28.0,
                  ),
                ),
            ],
          ),
          onTap: fileExists ? openFile : null,
        ),
      ),
    );
  }
}
