String? validateName(String? value) {
  if (value == null || value.isEmpty || value.length < 3 || value.length > 15) {
    return 'Name must be between 3 and 15 characters';
  }
  if (!RegExp(r'^[a-zA-Z]+$').hasMatch(value)) {
    return 'Name must contain only alphabetical characters';
  }
  return null;
}

String? validateLastName(String? value) {
  if (value == null || value.isEmpty || value.length < 3 || value.length > 15) {
    return 'Last Name must be between 3 and 15 characters';
  }
  if (!RegExp(r'^[a-zA-Z]+$').hasMatch(value)) {
    return 'Last Name must contain only alphabetical characters';
  }
  return null;
}

String? validateNationalCode(String? value) {
  if (value == null || value.isEmpty || !RegExp(r'^\d{10}$').hasMatch(value)) {
    return 'National Code must be 10 digits';
  }
  return null;
}

String? validatePassword(String? value) {
  if (value == null || value.isEmpty) {
    return 'Password is required';
  }
  if (value.length < 8) {
    return 'Password must be at least 8 characters';
  }
  if (!RegExp(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$').hasMatch(value)) {
    return 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character';
  }
  return null;
}
