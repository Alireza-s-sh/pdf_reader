// static_files.dart

final List<Map<String, String>> dataListStatic = [
  {
    'fileName': 'Networking_Fundamentals.pdf',
    'fileUrl':
        'https://www.cisco.com/c/dam/global/fi_fi/assets/docs/SMB_University_120307_Networking_Fundamentals.pdf',
    'fileDescription': 'Description of Book 1',
  },
  {
    'fileName': 'c how to program.pdf',
    'fileUrl':
        'https://dl.ebooksworld.ir/books/C.How.to.Program.9th.Edition.Paul.Deitel.Pearson.9780137398393.EBooksWorld.ir.pdf',
    'fileDescription': 'Description of Book 2',
  },
  {
    'fileName': 'information retrieval.pdf',
    'fileUrl':
        'https://www.utdallas.edu/~scortes/ochem/OChem_Lab1/recit_notes/ir_presentation.pdf',
    'fileDescription': 'Description of Book 2',
  },
  {
    'fileName': 'vhdl-tutorial.pdf',
    'fileUrl':
        'https://www.eecs.umich.edu/courses/doing_dsp/handout/vhdl-tutorial.pdf',
    'fileDescription': 'Description of Book 2',
  },
  // Add more items as needed
];
