// file_data.dart
import 'package:hive/hive.dart';

part 'file_data.g.dart';

@HiveType(typeId: 1)
class FileData extends HiveObject {
  @HiveField(0)
  final String fileName;

  @HiveField(1)
  final String fileUrl;

  @HiveField(2)
  final String fileDescription;

  FileData(
      {required this.fileName,
      required this.fileUrl,
      required this.fileDescription});
}
