import 'package:hive/hive.dart';

part 'user.g.dart';

@HiveType(typeId: 0)
class User extends HiveObject {
  @HiveField(0)
  String name;

  @HiveField(1)
  String lastName;

  @HiveField(2)
  String nationalCode;

  @HiveField(3)
  String userRole;

  @HiveField(4)
  String password;

  User({
    required this.name,
    required this.lastName,
    required this.nationalCode,
    required this.userRole,
    required this.password,
  });
}
