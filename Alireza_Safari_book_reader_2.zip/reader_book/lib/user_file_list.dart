import 'dart:io';
import 'package:book_reader/admin_panel.dart';
import 'package:book_reader/models/file_data.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:hive/hive.dart';
import 'package:book_reader/login_page.dart';
import 'package:open_file/open_file.dart';
import 'package:path/path.dart' as path;
import '../utils/check_permission.dart';
import '../utils/directory_path.dart';
import '../static_files.dart';

class UserFileList extends StatefulWidget {
  const UserFileList({Key? key}) : super(key: key);

  @override
  State<UserFileList> createState() => _FileListState();
}

class _FileListState extends State<UserFileList> {
  bool isPermission = false;
  var checkAllPermissions = CheckPermission();
  final _fileDataBox = Hive.box<FileData>('files');
  final dataList = List.from(dataListStatic);

  checkPermission() async {
    var permission = await checkAllPermissions.isStoragePermission();
    if (permission) {
      setState(() {
        isPermission = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    checkPermission();
  }

  @override
  Widget build(BuildContext context) {
    List<FileData> combinedData = [
      ...dataList.map((item) => FileData(
            fileName: item['fileName'] ?? '',
            fileUrl: item['fileUrl'] ?? '',
            fileDescription: item['fileDescription'] ?? '',
          )),
      ..._fileDataBox.values.toList()
    ];

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: HexColor("#f5f5f5"),
      appBar: AppBar(
        backgroundColor: HexColor("#f5f5f5"),
        title: Text(
          'Books',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: HexColor("#4F4F4F"),
          ),
        ),
        centerTitle: true,
      ),
      body: isPermission
          ? Stack(
              children: [
                ListView.builder(
                  padding: const EdgeInsets.all(8.0),
                  itemCount: combinedData.length,
                  itemBuilder: (BuildContext context, int index) {
                    var data = combinedData[index];
                    return TileList(
                      fileName: data.fileName,
                      fileUrl: data.fileUrl,
                      fileDescription: data.fileDescription,
                    );
                  },
                ),
              ],
            )
          : Center(
              child: ElevatedButton(
                onPressed: () {
                  checkPermission();
                },
                child: const Text("Grant Storage Permission"),
              ),
            ),
    );
  }
}

class TileList extends StatefulWidget {
  const TileList({
    Key? key,
    required this.fileName,
    required this.fileUrl,
    required this.fileDescription,
  }) : super(key: key);

  final String fileName;
  final String fileUrl;
  final String fileDescription;

  @override
  State<TileList> createState() => _TileListState();
}

class _TileListState extends State<TileList> {
  bool downloading = false;
  bool fileExists = false;
  double progress = 0;
  late String filePath;
  late CancelToken cancelToken;
  var getPathFile = DirectoryPath();

  startDownload() async {
    cancelToken = CancelToken();
    var storePath = await getPathFile.getPath();
    filePath = '$storePath/${widget.fileName}';

    setState(() {
      downloading = true;
      progress = 0;
    });

    try {
      await Dio().download(
        widget.fileUrl,
        filePath,
        onReceiveProgress: (count, total) {
          setState(() {
            progress = count / total;
          });
        },
        cancelToken: cancelToken,
      );

      setState(() {
        downloading = false;
        fileExists = true;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Download complete: ${widget.fileName}'),
          duration: const Duration(seconds: 3),
        ),
      );
    } catch (e) {
      print('Error downloading file: $e');
      setState(() {
        downloading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to download file: ${widget.fileName}'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  cancelDownload() {
    cancelToken.cancel();
    setState(() {
      downloading = false;
    });
  }

  checkFileExist() async {
    var storePath = await getPathFile.getPath();
    filePath = '$storePath/${widget.fileName}';
    bool fileExistCheck = await File(filePath).exists();
    setState(() {
      fileExists = fileExistCheck;
    });
  }

  deleteFile() async {
    var storePath = await getPathFile.getPath();
    filePath = '$storePath/${widget.fileName}';
    try {
      if (await File(filePath).exists()) {
        await File(filePath).delete();
        setState(() {
          fileExists = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('File deleted: ${widget.fileName}'),
            duration: const Duration(seconds: 3),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('File does not exist: ${widget.fileName}'),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      print('Error deleting file: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to delete file: ${widget.fileName}'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  openFile() {
    OpenFile.open(filePath);
  }

  @override
  void initState() {
    super.initState();
    checkFileExist();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20.0),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 10.0,
              spreadRadius: 5.0,
            ),
          ],
        ),
        child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: HexColor("#e0f7fa"),
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: const Icon(
                  Icons.picture_as_pdf,
                  size: 24.0,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.fileName,
                    style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w600,
                        color: HexColor("#4F4F4F")),
                  ),
                  const SizedBox(height: 4),
                ],
              ),
            ],
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!downloading && !fileExists)
                IconButton(
                  icon: const Icon(Icons.download),
                  onPressed: startDownload,
                  color: HexColor("#00a676"),
                ),
              if (downloading)
                CircularProgressIndicator(
                  value: progress,
                  strokeWidth: 2,
                  color: HexColor("#00a676"),
                ),
              if (downloading)
                IconButton(
                  icon: const Icon(Icons.cancel),
                  onPressed: cancelDownload,
                  color: Colors.red,
                ),
              if (fileExists)
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: deleteFile,
                  color: Colors.red,
                ),
              if (fileExists)
                IconButton(
                  icon: const Icon(Icons.open_in_new),
                  onPressed: openFile,
                  color: Colors.blue,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
