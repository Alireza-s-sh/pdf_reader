import 'package:book_reader/models/file_data.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:hive/hive.dart';

class AdminPanel extends StatefulWidget {
  @override
  _AdminPanelState createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  final TextEditingController _fileNameController = TextEditingController();
  final TextEditingController _filePathController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final fileBox = Hive.box<FileData>('files');
    List<FileData> fileList = fileBox.values.toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Admin Panel',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        backgroundColor: HexColor('#00796B'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(
              'Current Files',
              style: TextStyle(
                fontSize: 22.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: fileList.isEmpty
                  ? Center(
                      child: Text(
                        'No files available',
                        style: TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      itemCount: fileList.length,
                      itemBuilder: (context, index) {
                        FileData fileData = fileList[index];
                        return Card(
                          margin: EdgeInsets.symmetric(vertical: 8.0),
                          child: ListTile(
                            title: Text(
                              fileData.fileName,
                              style: TextStyle(fontSize: 18),
                            ),
                            trailing: IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                // Delete file logic
                                fileBox.delete(fileData.key);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        'File deleted: ${fileData.fileName}'),
                                  ),
                                );
                                setState(() {
                                  fileList.removeAt(index);
                                });
                              },
                            ),
                          ),
                        );
                      },
                    ),
            ),
            Divider(),
            Text(
              'Add New File',
              style: TextStyle(
                fontSize: 22.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _fileNameController,
              decoration: InputDecoration(
                labelText: 'File Name',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _filePathController,
              decoration: InputDecoration(
                labelText: 'File URL',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_fileNameController.text.isNotEmpty &&
                    _filePathController.text.isNotEmpty) {
                  final newFile = FileData(
                    fileName: _fileNameController.text,
                    fileUrl: _filePathController.text,
                    fileDescription: '',
                  );

                  fileBox.add(newFile);

                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('File added successfully'),
                  ));

                  _fileNameController.clear();
                  _filePathController.clear();
                  setState(() {
                    fileList.add(newFile);
                  });
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Please fill in all fields'),
                  ));
                }
              },
              style: ElevatedButton.styleFrom(
                primary: HexColor('#00796B'),
                padding: EdgeInsets.symmetric(vertical: 16.0),
                textStyle: TextStyle(fontSize: 18),
              ),
              child: Text(
                'Add File',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
